﻿<div class="container-fluid">
<h1 class="h3 mb-4 text-gray-800">FUNDING</h1>
<div class="card mb-4">
<div class="card-body">
<p>This project is funded by CLOSER and supported by a grant to the ESRC Mental Health Leadership Fellow.</p>
<div class="d-flex justify-content-around">
	<img style="max-width:250px" width="40%"src='img/closer_logo.svg'/><img style="max-width:250px" width="40%"src='img/esrc_logo.png'/>
</div>
</div>
</div>
</div>