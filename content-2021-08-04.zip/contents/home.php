
<div class="container-home">
<!--	<img class="splashImg" src="img/Home.jpg" alt="" /> -->
	<div class="homeRow splashImg d-flex align-items-center justify-content-between" style = "background-image: url(img/COVIDupdate_banner.jpg); -ms-background-position-x: center; -ms-background-position-y: bottom;  background-position: center bottom;  background-size: cover; min-height:250px; min-height:30vh; height:unset;padding:0.7rem;">
		<div class="homeInfoBox mb-2 col-md-4 d-lg-flex d-md-flex d-none flex-column align-items-center justify-content-around h-100">
			<h4 class="h2 mb-2 text-green-800 text-left" style="color:#b1e5a8;font-size:3.5vw;font-size: calc(2rem + (28 - 14) * ((100vw - 300px) / (1600 - 300)));">COVID-19 & THE CATALOGUE OF MENTAL HEALTH MEASURES</h4>
		</div>
		<div class="homeInfoBox mb-2 col-md-5 d-flex flex-column align-items-center justify-content-between h-100 ui-corner-all">
			<p class="mb-4 text-white text-center" style = "font-weight:800;">The longitudinal studies on the Catalogue will play a key role in answering crucial questions about the consequences of the pandemic on mental health and wellbeing. As the situation evolves, several initiatives are working to capture, understand and mitigate the impact of the pandemic on society.</p>
			<div class="text-center mb-4" style="max-width: 15rem;">
				<a class="h3" style = "border: solid #b1e5a8 2px; color:#b1e5a8; padding: 1rem; text-decoration: none;" href="?content=4">READ MORE</a></div>
		</div>
	</div>
	<div class="homeRow">
		<h4 class="h4 mb-2 text-green-800" style="text-align: center; width:80%;margin:auto;">An interactive catalogue of mental health and wellbeing measures in British cohort and longitudinal studies</h4>
		<div class="d-sm-flex align-items-top justify-content-between">
			<div class="homeInfoBox col-md-4">
				<p><i class="homeClipArt fas fa-leaf"></i></p>
				<p>The UK boasts rich and world-renowned cohort and longitudinal studies which offer unique opportunities to answer key questions about mental health and wellbeing.</p>
			</div>
			<div class="homeInfoBox col-md-4">
				<p><i class="homeClipArt fas fa-sun"></i></p>
				<p>The catalogue provides information about thousands of standard and non-standard measures of mental health and wellbeing collected in UK longitudinal studies.</p>
			</div>
			<div class="homeInfoBox col-md-4">
				<p><i class="homeClipArt fas fa-tree"></i></p>
				<p>Measures detailed in the catalogue include indicators of mental health problems, treatment, service use, impairment and psychological wellbeing.</p>
			</div>
		</div>	
		<div class="text-center mb-4" ><a href="?content=search"><img style="max-width:15rem;" src="img/Search_button.png" alt="Browse Mental Health Measures" /></a></div>
	</div>
	<div class="homeRow odd">
		<h4 id="Explore" class="h4 mb-2 text-green-800 text-center">EXPLORE MENTAL HEALTH MEASURES CATALOGUE</h4>
		<div class="d-md-flex align-items-top justify-content-between">
			<div class="homeInfoBox col-lg-6 d-flex flex-column align-items-top justify-content-around">
				<div class="d-flex align-items-center mb-1 mt-1">
					<i class="homeClipArt far fa-clipboard"></i>
					<p class="mb-0 text-left">30 longitudinal studies - 
						<a href="#Explore" class="searchLink">try searching for <i>"Born in Bradford"</i></a>
					</p>
				</div>
				<div class="d-flex align-items-center mb-1 mt-1">
					<i class="homeClipArt fas fa-ruler"></i>
					<p class="mb-0 text-left">Over 20 mental health and wellbeing topics - 
						<a href="#Explore" class="searchLink" >try searching <i>"depression"</i></a>
					</p>
				</div>
				<div class="d-flex align-items-center mb-1 mt-1">
					<img class="homeClipArt" src="img/Brain.png" alt="" />
					<p class="mb-0 text-left">Dozens of standard instruments - 
						<a href="#Explore" class="searchLink">try searching for the <i>SDQ or GHQ</i></a>
					</p>
				</div>
				<div class="d-flex align-items-center mb-1 mt-1">
					<input id="searchField" type="search" class="form-control" placeholder="Search for studies, measures, instruments…">
				</div>
			</div>
			<div class="homeInfoBox col-lg-6">
				<img style="width:100%;" src="video/CMHM_homepage2.gif"/>
			</div>
		</div>
	</div>
	<div class="homeRow">
		<div class="d-md-flex align-items-top justify-content-between">
			<div class="homeInfoBox col-sm-6">
				<h4 class="h4 mb-2 text-green-800" style="text-align: center; width:80%;margin:auto;">We want to hear from you!</h4>
				<p>The catalogue continues to grow as we add new studies, sweeps and measures. Is there something you think is missing, or would like to see on the platform? Get in touch with us by emailing <a href="mailto:mentalhealth.fellow@kcl.ac.uk">mentalhealth.fellow@kcl.ac.uk</a> with your feedback!</p>
			</div>
			<div class="homeInfoBox col-sm-6">
				<h4 class="h4 mb-2 text-green-800" style="text-align: center; width:80%;margin:auto;">Want to stay up to date?</h4>
				<p>Join our mailing list to receive updates when new studies, measures and resources are added to the catalogue!</p>
				<iframe width="540" height="305" src="https://c356a603.sibforms.com/serve/MUIEAJhBh4WdtGeQHhREoa2YYy8rgw07Rq9cQyy5bn6M9mS98u0EscwqQM-f0-M9k6OW_k0JI3VCmHwjoTyBQN22c6pVyKU6YU2XQcvs47IAsvhMOszWtcxb7Kf9VqYNqNu9lOhDSrASNCb2BKW2Gu9S0Wjw2clfAjNGfw64twHtPW_SL0wR3fvlGOdQM6Nz-NuOp1w651FrHmbi" frameborder="0" scrolling="auto" allowfullscreen style="display: block;margin-left: auto;margin-right: auto;max-width: 100%;"></iframe>
			</div>
		</div>
	</div>
</div>	


<script src="js/home.js" defer></script>
